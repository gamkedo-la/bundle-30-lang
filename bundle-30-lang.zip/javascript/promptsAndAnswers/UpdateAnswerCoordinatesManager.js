function UpdateAnswerCoordinatesManager()
{
  
}
