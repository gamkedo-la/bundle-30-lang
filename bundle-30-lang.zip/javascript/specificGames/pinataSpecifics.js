////////////////////////////////////////
var pinataGame = new bubblePoppingEngine('pinataGame',true);
var playerShouldBePlayingPinata = false; // FIXME is this still used elsewhere?
const PINATAFRAMERATE = 1000/60;
////////////////////////////////////////
