function canvasClick()
{
  if (titleScreen)
  {
    titleScreen = false;    
  }
}
